﻿ | FileName                  | Status | Component | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|-----------|----------|----------------|-------------|-------------|---------------|-------------|
 | onnxruntime.dll           | Pass   | Sign      | 10.71MB  | 53.87          | 1.46        | 0.32        | 52.01         | 0           | 
 | time_providers_shared.dll | Pass   | Sign      | 11.5KB   | 74.93          | 0.71        | 0.39        | 73.07         | 0           | 
